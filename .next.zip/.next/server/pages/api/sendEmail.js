"use strict";(()=>{var e={};e.id=4719,e.ids=[4719],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},6920:(e,t,r)=>{r.r(t),r.d(t,{config:()=>P,default:()=>h,routeModule:()=>y});var s={};r.r(s),r.d(s,{config:()=>g,default:()=>f});var a=r(1802),i=r(7153),n=r(6249);let o=require("multer");var d=r.n(o);let l=require("nodemailer");var u=r.n(l);let m=d()(),c=u().createTransport({host:"smtp.gmail.com",port:587,auth:{user:"deepakkumardeepak081@gmail.com",pass:"fojw wpzi fndt euiz"}}),p=async(e,t)=>{let r=`
    <div style="padding: 30px; border-style: solid; border-color: #f60; border-width: 1px;">
    <div style="width: 100%; height: 200px; margin-bottom: 0px;">
    <img
    style="width: 400px; height: 100px;"
              src='https://www.piemultilingual.com/enquiryform/img/logo.png'               
            
            />
            <p style='color:#000; line-height: 25px;'>Dear Admin,
    <br/>
    You have a new enquiry .
    <br/>
    Please see details:</p>
    </div>
    <table border='1'>
    <tr>
        <td>Name</td>
        <td style="">${e.name}</td>
    </tr>
    <tr>
        <td>Email</td>
        <td>${e.email}</td>
    </tr>
    <tr>
        <td>Phone</td>
        <td>${void 0!=e.phone||null!=e.phone?e.phone:""}</td>
    </tr>
    <tr>
        <td>Country</td>
        <td>${e.country}</td>
    </tr>
    <tr>
        <td>IP</td>
        <td>${e.IP}</td>
    </tr>
    <tr>
        <td>URL</td>
        <td>${e.url}</td>
    </tr>
    <tr>
        <td>Message</td>
        <td>${void 0!=e.message||null!=e.message?e.message:""}</td>
    </tr>
    <tr>
        <td>Date</td>
        <td>${e.date}</td>
    </tr>
    <tr>
        <td>role</td>
        <td>${void 0!=e.role||null!=e.role?e.role:""}</td>
    </tr>
</table>
<p style='color:#000;  line-height: 25px;'>Thanking You
<br/>
Pie Multilangual Services</p>

    </div>


`,s={from:"deepakkumardeepak081@gmail.com",to:"dewshikhaa@gmail.com",subject:"New Form Submission",html:`
            
            ${r}
        `,attachments:t.map(e=>({filename:e.originalname,content:e.buffer}))};try{return await c.sendMail(s),{success:!0,message:"Email sent successfully!"}}catch(e){throw console.error("Error sending email:",e),Error("Error sending email. Please try again later.")}},g={api:{bodyParser:!1}},f=async(e,t)=>{if("POST"!==e.method)return t.status(405).end();try{m.any()(e,t,async r=>{if(r)return console.error("Error uploading files:",r),t.status(500).json({success:!1,message:"Error uploading files."});let s=e.body;if(!s)return t.status(400).json({success:!1,message:"all fields are empty"});let a=e.files||[],i=await p(s,a);return t.status(i.success?200:500).json(i)})}catch(e){return console.error("Error processing form submission:",e),t.status(500).json({success:!1,message:"Error processing form submission."})}},h=(0,n.l)(s,"default"),P=(0,n.l)(s,"config"),y=new a.PagesAPIRouteModule({definition:{kind:i.x.PAGES_API,page:"/api/sendEmail",pathname:"/api/sendEmail",bundlePath:"",filename:""},userland:s})},7153:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},1802:(e,t,r)=>{e.exports=r(145)}};var t=require("../../webpack-api-runtime.js");t.C(e);var r=t(t.s=6920);module.exports=r})();